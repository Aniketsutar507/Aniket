/*
 * Name : Aniket Sutar
 * Submission Date: 28/05/2024
 * Project : Car Black Box
 */

#ifndef ADC_H
#define	ADC_H

void init_adc(void);
unsigned short read_adc(void);

#endif	/* ADC_H */